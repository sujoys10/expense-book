import React from "react";

const TodoInput = ({ isPublic = false }) => {
  return (
    <form
      className="formInput"
      onSubmit={e => {
        e.preventDefault();
      }}
    >
      <input className="input" placeholder="What needs to be done?" />
      <i className="inputMarker fa fa-angle-right" />
    </form>
  );
};

export default TodoInput;
