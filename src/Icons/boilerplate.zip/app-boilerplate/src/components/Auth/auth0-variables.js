export const AUTH_CONFIG = {
  domain: 'graphql-tutorials.auth0.com',
  clientId: 'P38qnFo1lFAQJrzkun--wEzqljVNGcWW',
  callbackUrl: 'http://localhost:3000/callback'
};
