Tutorial
--------

- [React](https://learn.hasura.io/graphql/react/introduction)
- [Hasura GraphQL Endpoint](https://learn.hasura.io/graphql)

Tech stack
----------

- Frontend
    - React v16.8

Run the React app
-----------------

Run `npm start` to start the todo app.